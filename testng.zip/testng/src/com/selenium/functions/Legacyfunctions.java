package com.selenium.functions;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.selenium.base.Testbase;
import com.selenium.pom.CartPage;
import com.selenium.pom.Homepage;

public class Legacyfunctions extends Testbase {

	public static void Searchitem(String item) {
		// TODO Auto-generated method stub
		try {

			wait = new WebDriverWait(driver, 300);
			//Homepage.popup_click(driver, wait).click();
			
			String NewTab = Keys.chord(Keys.CONTROL,Keys.RETURN); 
            driver.findElement(By.name("button")).sendKeys(NewTab);
            
            ArrayList<String> tab= new ArrayList<String>(driver.getWindowHandles());
     
     
            driver.switchTo().window(tab.get(1)); 


			Homepage Home = PageFactory.initElements(driver, Homepage.class);

			Home.Searchitem.sendKeys(item);
			Assert.assertEquals(Home.Searchitem.getAttribute("value"), item);

			Home.Search_Box.click();
			WebElement element = driver.findElement(By.linkText("Printed Chiffon Dress"));
			if (element != null) {

				System.out.println("success search");

			} else {
				System.out.println("search fail");

			}
		} catch (Exception e) {
			// TODO: handle exception

		}

	}
}
