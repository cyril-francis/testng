package com.selenium.functions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.selenium.base.Testbase;
import com.selenium.pom.CartPage;
import com.selenium.pom.Homepage;
import com.selenium.pom.RegistrationPom;

public class AddCart extends Testbase {

	public static void Add() {

		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")
					+ "src\\com\\selenium\\config\\login.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			prop.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RegistrationPom RegisterUser = PageFactory.initElements(driver, RegistrationPom.class);

		wait = new WebDriverWait(driver, 100);
		Homepage.popup_click(driver, wait).click();
		RegisterUser.Signin_Link.click();

		CartPage AddToCart = PageFactory.initElements(driver, CartPage.class);

		/*
		 * CartPage.email(driver).sendKeys(prop.getProperty("username1"));
		 * CartPage.password(driver).sendKeys(prop.getProperty("password1"));
		 * CartPage.submit(driver).click();
		 * CartPage.search(driver).sendKeys("T shirt");
		 * Assert.assertEquals(CartPage.search(driver).getAttribute("value"),
		 * "T shirt"); CartPage.submitsearch(driver).click();
		 * CartPage.addtocart(driver).click(); WebElement newElement =
		 * CartPage.proceed(driver); if (!newElement.equals(null)) {
		 * System.out.println("pass"); }
		 */

		AddToCart.email.sendKeys(prop.getProperty("username1"));
		AddToCart.password.sendKeys(prop.getProperty("password1"));
		AddToCart.submit.click();
		AddToCart.search.sendKeys("T shirt");
		Assert.assertEquals(AddToCart.search.getAttribute("value"), "T shirt");
		AddToCart.submitsearch.click();
		AddToCart.addtocart.click();
		WebElement newElement = AddToCart.proceed;
		if (!newElement.equals(null)) {
			System.out.println("pass");
		}
	}
}
