package com.selenium.functions;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.selenium.base.Testbase;

public class GenericFunctionlib extends Testbase {

	public static void openBrowser(String url) throws IOException {
		
		/* System.setProperty("webdriver.chrome.driver",
		 "C:\\Users\\u60898\\Downloads\\chromedriver_win32\\chromedriver.exe");
		 
		
		  Properties prop = new Properties(); 
		  InputStream input = null; 
		  input =new FileInputStream(System.getProperty("user.dir") +
		  System.getProperty("file.separator") +
		  "src\\com\\selenium\\config\\configure.properties");
		  prop.load(input);
		  driver = new ChromeDriver();*/
		
		 /* System.setProperty("webdriver.ie.driver",
		  "C:\\Users\\u60898\\Downloads\\IEDriverServer_x64_3.4.0\\IEDriverServer.exe" );*/
		 
		
		
		if (browser.equals("ie")) {
			
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			  
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "IE");
			capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capabilities.setCapability(InternetExplorerDriver.
			  INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			
			System.setProperty("webdriver.ie.driver",
					"C:\\Users\\u60898\\Downloads\\IEDriverServer_Win32_3.4.0\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\u60898\\Downloads\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		driver.get(url);// reading url

	}

	public static void closeBrowser() {
		driver.quit();
	}

	/*
	 * public static void exception() { int a = 1 / 0; }
	 */

}
