package com.selenium.functions;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.selenium.base.Testbase;
import com.selenium.pom.RegistrationPom;

public class RegisterFunction extends Testbase {

	public static void Registration(String email, String gender, String fname, String lname, String password,
			String dob, String company, String address1, String address2, String city, String state, String pincode,
			String phone) {
		// TODO Auto-generated method stub

		Properties prop = new Properties();

		/*
		 * try { wait = new WebDriverWait(driver, 100);
		 * RegistrationPom.popup_click(driver, wait).click();
		 * 
		 * RegistrationPom.Signin_Link(driver).click();
		 * 
		 * String mailid = email + System.currentTimeMillis() + "@gmail.com";
		 * RegistrationPom.email(driver).sendKeys(mailid); String uname =
		 * "username" + i; prop.setProperty(uname, mailid);
		 * Assert.assertEquals(RegistrationPom.email(driver).getAttribute(
		 * "value"), mailid); RegistrationPom.submit(driver).click();
		 * 
		 * if (gender.equals("male")) {
		 * 
		 * RegistrationPom.gender1(driver, wait).click();
		 * 
		 * } else
		 * 
		 * { RegistrationPom.gender2(driver, wait).click();
		 * 
		 * }
		 * 
		 * RegistrationPom.fname(driver).sendKeys(fname);
		 * Assert.assertEquals(RegistrationPom.fname(driver).getAttribute(
		 * "value"), fname);
		 * 
		 * RegistrationPom.lname(driver).sendKeys(lname);
		 * Assert.assertEquals(RegistrationPom.lname(driver).getAttribute(
		 * "value"), lname);
		 * RegistrationPom.password(driver).sendKeys(password);
		 * Assert.assertEquals(RegistrationPom.password(driver).getAttribute(
		 * "value"),password); prop.setProperty("password" + i, password); try {
		 * prop.store(output, null); } catch (IOException e1) { // TODO
		 * Auto-generated catch block e1.printStackTrace(); } i++; Select
		 * selectDays = new Select(RegistrationPom.day(driver)); String[] date =
		 * dob.split("/"); selectDays.selectByValue(date[0]); Select
		 * selectMonths = new Select(RegistrationPom.month(driver));
		 * selectMonths.selectByValue(date[1]); Select selectYear = new
		 * Select(RegistrationPom.year(driver));
		 * selectYear.selectByValue(date[2]);
		 * 
		 * RegistrationPom.company(driver).sendKeys(company);
		 * Assert.assertEquals(RegistrationPom.company(driver).getAttribute(
		 * "value"), company);
		 * 
		 * RegistrationPom.address1(driver).sendKeys(address1);
		 * Assert.assertEquals(RegistrationPom.address1(driver).getAttribute(
		 * "value"), address1);
		 * RegistrationPom.address2(driver).sendKeys(address2);
		 * Assert.assertEquals(RegistrationPom.address2(driver).getAttribute(
		 * "value"), address2); RegistrationPom.city(driver).sendKeys(city);
		 * Assert.assertEquals(RegistrationPom.city(driver).getAttribute("value"
		 * ), city); Select selectState = new
		 * Select(RegistrationPom.state(driver));
		 * selectState.selectByVisibleText(state);
		 * RegistrationPom.postcode(driver).sendKeys(pincode);
		 * Assert.assertEquals(RegistrationPom.postcode(driver).getAttribute(
		 * "value"), pincode);
		 * 
		 * RegistrationPom.mobile(driver).sendKeys(phone);
		 * Assert.assertEquals(RegistrationPom.mobile(driver).getAttribute(
		 * "value"), phone); RegistrationPom.Submitaccount(driver,
		 * wait).click(); WebElement element =
		 * driver.findElement(By.className("icon-user")); if (element != null) {
		 * 
		 * System.out.println("Registration success ");
		 * 
		 * } else { System.out.println("Registration fail");
		 * 
		 * }
		 * 
		 * }
		 * 
		 * catch (Exception e) {
		 * 
		 * }
		 */

		try {

			RegistrationPom RegisterUser = PageFactory.initElements(driver, RegistrationPom.class);

			wait = new WebDriverWait(driver, 100);
			RegistrationPom.popup_click(driver, wait).click();

			RegisterUser.Signin_Link.click();

			String mailid = email + System.currentTimeMillis() + "@gmail.com";
			RegisterUser.email.sendKeys(mailid);
			String uname = "username" + i;
			prop.setProperty(uname, mailid);
			Assert.assertEquals(RegisterUser.email.getAttribute("value"), mailid);
			RegisterUser.submit.click();

			if (gender.equals("male")) {

				RegistrationPom.gender1(driver, wait).click();

			} else

			{
				RegistrationPom.gender2(driver, wait).click();

			}

			RegisterUser.fname.sendKeys(fname);
			Assert.assertEquals(RegisterUser.fname.getAttribute("value"), fname);

			RegisterUser.lname.sendKeys(lname);
			Assert.assertEquals(RegisterUser.lname.getAttribute("value"), lname);
			RegisterUser.password.sendKeys(password);
			Assert.assertEquals(RegisterUser.password.getAttribute("value"), password);
			prop.setProperty("password" + i, password);
			try {
				prop.store(output, null);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			i++;
			Select selectDays = new Select(RegisterUser.day);
			String[] date = dob.split("/");
			selectDays.selectByValue(date[0]);
			Select selectMonths = new Select(RegisterUser.month);
			selectMonths.selectByValue(date[1]);
			Select selectYear = new Select(RegisterUser.year);
			selectYear.selectByValue(date[2]);

			RegisterUser.company.sendKeys(company);
			Assert.assertEquals(RegisterUser.company.getAttribute("value"), company);

			RegisterUser.address1.sendKeys(address1);
			Assert.assertEquals(RegisterUser.address1.getAttribute("value"), address1);
			RegisterUser.address2.sendKeys(address2);
			Assert.assertEquals(RegisterUser.address2.getAttribute("value"), address2);
			RegisterUser.city.sendKeys(city);
			Assert.assertEquals(RegisterUser.city.getAttribute("value"), city);
			Select selectState = new Select(RegisterUser.state);
			selectState.selectByVisibleText(state);
			RegisterUser.postcode.sendKeys(pincode);
			Assert.assertEquals(RegisterUser.postcode.getAttribute("value"), pincode);

			RegisterUser.mobile.sendKeys(phone);
			Assert.assertEquals(RegisterUser.mobile.getAttribute("value"), phone);
			RegistrationPom.Submitaccount(driver, wait).click();
			WebElement element = driver.findElement(By.className("icon-user"));
			if (element != null) {

				System.out.println("Registration success ");

			} else {
				System.out.println("Registration fail");

			}

		}

		catch (Exception e) {

		}
	}
}
