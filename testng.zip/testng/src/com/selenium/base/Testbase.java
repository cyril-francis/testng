package com.selenium.base;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.util.Xls_Reader;

public class Testbase {
	public static WebDriver driver = null;
	public static WebDriverWait wait = null;
	public static Xls_Reader suiteAxls = null;
	public static boolean isInitalized = false;
	public static FileOutputStream output;
	public static int i = 1;
	public static String browser;
	public static String url;

	public void initialize() {
		DOMConfigurator.configure("log4j.xml");
		if (!isInitalized) {
			suiteAxls = new Xls_Reader(
					System.getProperty("user.dir") + "\\src\\com\\selenium\\testdata\\TestData.xlsx");
			isInitalized = true;
		}
		try {
			output = new FileOutputStream(System.getProperty("user.dir") + System.getProperty("file.separator")
					+ "src\\com\\selenium\\config\\login.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
