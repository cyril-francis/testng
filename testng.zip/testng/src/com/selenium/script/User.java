package com.selenium.script;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.Testbase;
import com.selenium.functions.AddCart;
import com.selenium.functions.GenericFunctionlib;
import com.selenium.functions.RegisterFunction;
import com.selenium.listener.Retry;
import com.selenium.util.TestUtil;

public class User extends Testbase {

	static boolean skip = false;
	static boolean fail = false;
	static boolean test = false;

	@BeforeTest(alwaysRun = true)
	@Parameters({ "url", "browser" })
	public void TestCaseRunnable(String url, String browser) {
		initialize();
		Testbase.url = url;
		Testbase.browser = browser;
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {

			throw new SkipException("The test case of" + this.getClass().getSimpleName() + "set to NO");
		}
	}

	@Test(/*retryAnalyzer = Retry.class,*/ groups={"primary"},dataProvider = "RegisterData"/*,enabled=false*//*, expectedExceptions = ArithmeticException.class*/)
	public void UserRegistration(String email, String gender, String fname, String lname, String password, String dob,
			String company, String address1, String address2, String city, String state, String pincode, String phone) {

		
		try {
			GenericFunctionlib.openBrowser(url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RegisterFunction.Registration(email, gender, fname, lname, password, dob, company, address1, address2, city,
				state, pincode, phone);
		//GenericFunctionlib.exception();
		GenericFunctionlib.closeBrowser();
		test = true;
	}

	@Test(dependsOnMethods = { "UserRegistration" }/*,enabled=false*/)
	public void AddToCart() {
		try {
			GenericFunctionlib.openBrowser(url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		AddCart.Add();
		GenericFunctionlib.closeBrowser();
	}

	@DataProvider
	public Object[][] RegisterData() {
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName());
	}

	@AfterTest
	public void TestCaseResult() {
		if (test) {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Pass");
		} else {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Fail");
		}
	}

	@AfterMethod
	public void DataSetResult() {
		if (skip) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Skip");
		} else if (fail) {
			test = false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Fail");
		} else {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Pass");
		}
		skip = false;
		fail = false;
	}
}
