package com.selenium.script;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.Testbase;
import com.selenium.functions.GenericFunctionlib;
import com.selenium.functions.Legacyfunctions;
import com.selenium.util.TestUtil;

public class Searchitems extends Testbase {

	static boolean skip = false;
	static boolean fail = false;
	static boolean test = false;

	@BeforeTest
	@Parameters({ "url", "browser" })
	public void TestCaseRunnable(String url, String browser) {
		initialize();
		Testbase.url = url;
		Testbase.browser = browser;
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {

			throw new SkipException("The test case of" + this.getClass().getSimpleName() + "set to NO");
		}
	}

	@Test(groups={"smoke"},dataProvider = "SearchItemData")
	public void Searchitemsmethod(String searchitemsvalue) {

		try {
			GenericFunctionlib.openBrowser(url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Legacyfunctions.Searchitem(searchitemsvalue);
		GenericFunctionlib.closeBrowser();
		test = true;
	}
	
	/*@Test(priority=2)
	public void b_method(){
	System.out.println("method b");
	}
	@Test(priority=1)
	public void a_method(){
	System.out.println("method a");
	}
	@Test(priority=3)
	public void c_method(){
	System.out.println("method c");
	}*/

	@DataProvider
	public Object[][] SearchItemData() {
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName());
	}

	@AfterTest
	public void TestCaseResult() {
		if (test) {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Pass");
		} else {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Fail");
		}
	}

	@AfterMethod
	public void DataSetResult() {
		if (skip) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Skip");
		} else if (fail) {
			test = false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Fail");
		} else {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Pass");
		}
		skip = false;
		fail = false;
	}
}
