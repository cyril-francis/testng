package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.selenium.base.Testbase;

public class CartPage extends Testbase {

	/*
	 * public static WebElement element;
	 * 
	 * public static WebElement email(WebDriver driver) { element =
	 * driver.findElement(By.id("email")); return element; }
	 * 
	 * public static WebElement password(WebDriver driver) { element =
	 * driver.findElement(By.id("passwd")); return element; }
	 * 
	 * public static WebElement submit(WebDriver driver) { element =
	 * driver.findElement(By.id("SubmitLogin")); return element; }
	 * 
	 * public static WebElement search(WebDriver driver) { element =
	 * driver.findElement(By.id("search_query_top")); return element; }
	 * 
	 * public static WebElement submitsearch(WebDriver driver) { element =
	 * driver.findElement(By.name("submit_search")); return element; }
	 * 
	 * public static WebElement addtocart(WebDriver driver) { element =
	 * driver.findElement(By.linkText("Add to cart")); return element; }
	 * 
	 * public static WebElement proceed(WebDriver driver) { element =
	 * driver.findElement(By.xpath(
	 * "//div[@class='layer_cart_product_info']/span")); return element; }
	 */
	final WebDriver driver;

	@FindBy(how = How.ID, using = "email")
	public WebElement email;
	@FindBy(how = How.ID, using = "passwd")
	public WebElement password;
	@FindBy(how = How.ID, using = "SubmitLogin")
	public WebElement submit;
	@FindBy(how = How.ID, using = "search_query_top")
	public WebElement search;
	@FindBy(how = How.NAME, using = "submit_search")
	public WebElement submitsearch;
	@FindBy(how = How.LINK_TEXT, using = "Add to cart")
	public WebElement addtocart;
	@FindBy(how = How.XPATH, using = "//div[@class='layer_cart_product_info']/span")
	public WebElement proceed;

	public CartPage(WebDriver driver)

	{
		this.driver = driver;

	}

}
