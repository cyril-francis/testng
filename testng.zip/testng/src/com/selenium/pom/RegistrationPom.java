package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class RegistrationPom extends Testbase {
	public static WebElement element;

	public static WebElement popup_click(WebDriver driver, WebDriverWait waitelement) {
		element = waitelement.until(ExpectedConditions.elementToBeClickable(By.name("button")));
		return element;
	}

	/*
	 * public static WebElement Signin_Link(WebDriver driver) { element =
	 * driver.findElement(By.className("login")); return element; }
	 * 
	 * public static WebElement email(WebDriver driver) { element =
	 * driver.findElement(By.id("email_create")); return element; }
	 * 
	 * public static WebElement submit(WebDriver driver) { element =
	 * driver.findElement(By.id("SubmitCreate")); return element; }
	 */

	public static WebElement gender1(WebDriver driver, WebDriverWait waitelement) {
		element = waitelement.until(ExpectedConditions.elementToBeClickable(By.id("id_gender1")));
		return element;
	}

	/*
	 * public static WebElement gender01(WebDriver driver) { element =
	 * driver.findElement(By.id("id_gender1")); return element; }
	 */

	public static WebElement gender2(WebDriver driver, WebDriverWait waitelement) {
		element = waitelement.until(ExpectedConditions.elementToBeClickable(By.id("id_gender2")));
		return element;
	}

	/*
	 * public static WebElement gender02(WebDriver driver) { element =
	 * driver.findElement(By.id("id_gender2")); return element; }
	 * 
	 * public static WebElement fname(WebDriver driver) { element =
	 * driver.findElement(By.id("customer_firstname")); return element; }
	 * 
	 * public static WebElement lname(WebDriver driver) { element =
	 * driver.findElement(By.id("customer_lastname")); return element; }
	 * 
	 * public static WebElement password(WebDriver driver) { element =
	 * driver.findElement(By.id("passwd")); return element; }
	 * 
	 * public static WebElement day(WebDriver driver) { element =
	 * driver.findElement(By.id("days")); return element; }
	 * 
	 * public static WebElement month(WebDriver driver) { element =
	 * driver.findElement(By.id("months")); return element; }
	 * 
	 * public static WebElement year(WebDriver driver) { element =
	 * driver.findElement(By.id("years")); return element; }
	 * 
	 * public static WebElement company(WebDriver driver) { element =
	 * driver.findElement(By.id("company")); return element; }
	 * 
	 * public static WebElement address1(WebDriver driver) { element =
	 * driver.findElement(By.id("address1")); return element; }
	 * 
	 * public static WebElement address2(WebDriver driver) { element =
	 * driver.findElement(By.id("address2")); return element; }
	 * 
	 * public static WebElement city(WebDriver driver) { element =
	 * driver.findElement(By.id("city")); return element; }
	 * 
	 * public static WebElement state(WebDriver driver) { element =
	 * driver.findElement(By.id("id_state")); return element; }
	 * 
	 * public static WebElement postcode(WebDriver driver) { element =
	 * driver.findElement(By.id("postcode")); return element; }
	 * 
	 * public static WebElement mobile(WebDriver driver) { element =
	 * driver.findElement(By.id("phone_mobile")); return element; }
	 */

	public static WebElement Submitaccount(WebDriver driver, WebDriverWait waitelement) {
		element = waitelement.until(ExpectedConditions.elementToBeClickable(By.id("submitAccount")));
		return element;
	}

	final WebDriver driver;

	@FindBy(how = How.CLASS_NAME, using = "login")
	public WebElement Signin_Link;
	@FindBy(how = How.ID, using = "email_create")
	public WebElement email;
	@FindBy(how = How.ID, using = "SubmitCreate")
	public WebElement submit;
	@FindBy(how = How.ID, using = "id_gender1")
	public WebElement gender01;
	@FindBy(how = How.ID, using = "id_gender2")
	public WebElement gender02;
	@FindBy(how = How.ID, using = "customer_firstname")
	public WebElement fname;
	@FindBy(how = How.ID, using = "customer_lastname")
	public WebElement lname;
	@FindBy(how = How.ID, using = "passwd")
	public WebElement password;
	@FindBy(how = How.ID, using = "days")
	public WebElement day;
	@FindBy(how = How.ID, using = "months")
	public WebElement month;
	@FindBy(how = How.ID, using = "years")
	public WebElement year;
	@FindBy(how = How.ID, using = "company")
	public WebElement company;
	@FindBy(how = How.ID, using = "address1")
	public WebElement address1;
	@FindBy(how = How.ID, using = "address2")
	public WebElement address2;
	@FindBy(how = How.ID, using = "city")
	public WebElement city;
	@FindBy(how = How.ID, using = "id_state")
	public WebElement state;
	@FindBy(how = How.ID, using = "postcode")
	public WebElement postcode;
	@FindBy(how = How.ID, using = "phone_mobile")
	public WebElement mobile;

	public RegistrationPom(WebDriver driver)

	{
		this.driver = driver;

	}
}
